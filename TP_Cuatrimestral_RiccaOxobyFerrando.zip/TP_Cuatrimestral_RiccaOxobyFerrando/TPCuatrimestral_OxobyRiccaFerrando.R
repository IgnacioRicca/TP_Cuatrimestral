install.packages('tidyverse')
install.packages('dbplyr')
install.packages('RSQLite')
library(tidyverse)
library(dbplyr)
library(RSQLite)
mimic_con <- dbConnect(RSQLite::SQLite(),"C:/Users/Sebastian/mimic3_demo.db")
dbListTables(mimic_con) #con esto veo las tablas que hay en mimic_con
d_icd_diagnoses <- tbl(mimic_con, 'D_ICD_DIAGNOSES')
icu_stays <- tbl(mimic_con, 'ICUSTAYS')
diagnoses <- tbl (mimic_con, 'DIAGNOSES_ICD')
admissions <- tbl(mimic_con, 'ADMISSIONS')
prescriptions <- tbl(mimic_con, 'PRESCRIPTIONS')
patients <- tbl(mimic_con, 'PATIENTS')
procedures <- tbl(mimic_con, "PROCEDURES_ICD")

# Vemos los icd9_codes mas utilizados en diagnosis, elegimos analizar la primer enfermedad del ranking
icd9_codes_n <- diagnoses %>% select(icd9_code) %>% group_by(icd9_code) %>% summarise(code_count = n()) %>% arrange(desc(code_count))
# La primer enfermedad esta en el rango 0 - 999 de los codigos, dentro de los 10 codigos mas usados estaba el 486, sabemos que es la neumonia por el uso del diccionario.
neumonia <- diagnoses %>% filter(icd9_code == "486")

#Juntamos la tabla de neumonia con la de prescriptions y procedures para luego conseguir los datos de los remedios y los procedimientos mas utilizados en los pacientes con neumonia.
neumonia_join_prescriptions <- inner_join(neumonia, prescriptions, by = "subject_id")
head(neumonia_join_prescriptions)


head(neumonia_join_prescriptions, 30)

nrow(neumonia)
#[1] NA
neumonia_join_prescriptions %>% head(100) %>% collect() %>% View()
neumonia_join_prescriptions %>% collect() %>% View()
neumonia_join_procedures <- inner_join(neumonia, procedures, by = "subject_id")

remedios <- neumonia_join_prescriptions %>% select(drug) %>% group_by(drug) %>% summarise(code_count = n()) %>% arrange(desc(code_count))
head(remedios)


remedios %>% collect() %>% tail(10)

procedimientos <- neumonia_join_procedures %>% select(icd9_code.y) %>% group_by(icd9_code.y) %>% summarise(code_count = n()) %>% arrange(desc(code_count))
procedimientos %>% collect()  %>% View()
head(procedimientos)

procedimientos_38963 <- neumonia_join_procedures %>% filter(icd9_code.y == "3893") 
procedimientos_38963_id <- procedimientos_38963 %>% select("subject_id")
inner_join(procedimientos_38963_id, admissions, by = "subject_id")

inner_join(procedimientos_38963_id, admissions, by = "subject_id") %>% View()
inner_join(procedimientos_38963_id, admissions, by = "subject_id") %>% collect()%>% View()
procedimientos_38963_ad <- inner_join(procedimientos_38963_id, admissions, by = "subject_id") %>% collect()%>% View()
procedimientos_38963_ad <- inner_join(procedimientos_38963_id, admissions, by = "subject_id") 
procedimientos_38963_ad %>% select(discharge_location) %>% group_by(discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count))

procedimientos_966 <- neumonia_join_procedures %>% filter(icd9_code.y == "966") 
procedimientos_966_id <- procedimientos_966 %>% select("subject_id")
procedimientos_966_ad <- inner_join(procedimientos_966_id, admissions, by = "subject_id") 
procedimientos_966_ad %>% select(discharge_location) %>% group_by(discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count))

procedimientos_9604 <- neumonia_join_procedures %>% filter(icd9_code.y == "9604") 
procedimientos_9604_id <- procedimientos_9604 %>% select("subject_id")
procedimientos_9604_ad <- inner_join(procedimientos_9604_id, admissions, by = "subject_id") 
procedimientos_9604_ad %>% select(discharge_location) %>% group_by(discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count))

procedimientos_9671 <- neumonia_join_procedures %>% filter(icd9_code.y == "9671") 
procedimientos_9671_id <- procedimientos_9671 %>% select("subject_id")
procedimientos_9671_ad <- inner_join(procedimientos_9671_id, admissions, by = "subject_id") 
procedimientos_9671_ad %>% select(discharge_location) %>% group_by(discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count))

procedimientos %>% arrange(desc(code_count)) %>% collect() %>% slice(1:5)
procedimientos_filtro <- procedimientos %>% arrange(desc(code_count)) %>% collect() %>% slice(1:5)
procedimientos_5 <- neumonia_join_procedures %>% filter(icd9_code.y %in% procedimientos_filtro$icd9_code.y)

procedimientos_5 <- neumonia_join_procedures %>% collect() %>% filter(icd9_code.y %in% procedimientos_filtro$icd9_code.y)

procedimientos_5_ad <- inner_join(procedimientos_5, admissions, by = "subject_id")
procedimientos_5_ad <- inner_join(procedimientos_5, collect(admissions), by = "subject_id")

procedimientos_5_ad %>% select(discharge_location, icd9_code.y) %>% group_by( icd9_code.y, discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count))
procedimientos_5_ad %>% select(discharge_location, icd9_code.y) %>% group_by( icd9_code.y, discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count)) %>% filter(discharge_location == "DEAD/EXPIRED")
procedimientos_5_muertes <- procedimientos_5_ad %>% select(discharge_location, icd9_code.y) %>% group_by( icd9_code.y, discharge_location) %>% summarise(code_count = n()) %>% arrange(desc(code_count)) %>% filter(discharge_location == "DEAD/EXPIRED")
inner_join(procedimientos_5_muertes, procedimientos_5, by = "icd9_code.y")

join <- inner_join(procedimientos_5_muertes, procedimientos_5, by = "icd9_code.y")
table(join$icd9_code.y)
merge(join, table(join$icd9_code.y))
merge(join, table(join$icd9_code.y)) %>% unique()
table(join$icd9_code.y)
nueva_tabla <- data.frame(icd9_code.y = names(table(join$icd9_code.y)), frecuencia = as.numeric(table(join$icd9_code.y)))
nueva_tabla
grafico <- data.frame(merge(nueva_tabla, join, by = "icd9_code.y")$icd9_code.y)
grafico <- data.frame(merge(nueva_tabla, join, by = "icd9_code.y")$icd9_code.y,merge(nueva_tabla, join, by = "icd9_code.y")$frecuencia,merge(nueva_tabla, join, by = "icd9_code.y")$code_count)
grafico <- data.frame(merge(nueva_tabla, join, by = "icd9_code.y")$icd9_code.y,merge(nueva_tabla, join, by = "icd9_code.y")$frecuencia,merge(nueva_tabla, join, by = "icd9_code.y")$code_count)
merge_tablas <- merge(nueva_tabla, join, by = "icd9_code.y")
grafico <- data.frame(merge_tablas$icd9_code.y,merge_tablas$frecuencia,merge_tablas$code_count)

icd9_codes_n <- diagnoses %>% select(icd9_code) %>% group_by(icd9_code) %>% summarise(code_count = n()) %>% arrange(desc(code_count))



neumonia_join_patients <- inner_join(neumonia, patients, by = "subject_id")

edades <- neumonia_join_patients %>% select(dob) %>% group_by(dob) %>% summarise(code_count = n()) %>% arrange(desc(code_count))


neumonia_join_patients <- neumonia_join_patients %>% mutate(año = year(dob))

neumonia_join_patients <- neumonia_join_patients %>%mutate(año = year(dob))
          

library(lubridate)
neumonia_join_patients <- neumonia_join_patients %>% mutate(año = year(dob))

edades <- neumonia_join_patients %>% mutate(diferencia = dod - dob)
edades_orden <- edades %>% select(diferencia) %>% group_by(diferencia) %>% summarise(code_count = n()) %>% arrange(desc(code_count))

if(! "ggmosaic" %in% installed.packages()){ install.packages("ggmosaic")}
library(ggmosaic)

edades_filtro_filtro <- edades_filtro %>%
  mutate(grupo_edad = case_when(
    diferencia >= 0 & diferencia <= 20 ~ "0-20",
    diferencia > 20 & diferencia <= 30 ~ "21-30",
    diferencia > 30 & diferencia <= 40 ~ "31-40",
    diferencia > 40 & diferencia <= 50 ~ "41-50",
    diferencia > 50 & diferencia <= 60 ~ "51-60",
    diferencia > 60 & diferencia <= 70 ~ "61-70",
    diferencia > 70 & diferencia <= 80 ~ "71-80",
    diferencia > 81  ~ "81+"
      ))

ggplot(data = grafico, aes(x = merge_tablas.frecuencia, y = merge_tablas.code_count)) +
  geom_point() +
  labs(x = "Operaciones Realizadas", y = "Fallecimientos", title = "Gráfico de dispersión")+
  theme_minimal()+
  geom_smooth(formula = y ~ x, method = "lm", colour = "red", linetype = 5)+
  geom_line(colour = "grey")

ggplot(edades_filtro_filtro, aes(x = grupo_edad)) +
  geom_bar(stat = "count",
           fill = "#FF6600") +
  labs(title = "Histograma de Edades de Pacientes con Neumonia", x = "Edad", y = "Frecuencia")+
  theme_minimal()
